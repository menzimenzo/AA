const di = require('./di')

module.exports = Object.assign({}, di)
