const testMail = {
    to: 'smtp.synaltic@gmail.com',
    body: 'I send an email'
}

module.exports = {
    testMail
}
