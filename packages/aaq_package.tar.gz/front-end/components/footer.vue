<template>
<div  class="appLabel mb-2 mt-5 ">
    <b-container>
      <b-row>
          <b-col cols="12 text-center">
              SI Aisance Aquatique - Version 1.0.0
          </b-col>
          <b-col cols="12 text-center">
              Contact :<i class="material-icons ml-2 mr-1" >mail</i>AisanceAquatique@sports.gouv.fr
          </b-col>


      </b-row>
    </b-container>

</div>

</template>

<style>

.appLabel{
  background-color: white;
  color: black;
  opacity: 0.5;
  border-top: 2px solid #aaa;
  border-bottom: 2px solid #aaa;
  padding: 15px 0px;

}

.material-icons{
  position: relative;
  top: 6px;
}
</style>