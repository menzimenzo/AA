<template>

	<svg version="1.1" x="0px" y="0px" viewBox="0 0 100 100" style="enable-background:new 0 0 100 100;">
        <g transform="rotate(45 50 50)">
            <g>
                <path class="st1" d="M50,81.3c-2.1,0-3.8-1.7-3.8-3.8v-55c0-2.1,1.7-3.8,3.8-3.8s3.8,1.7,3.8,3.8v55C53.8,79.6,52.1,81.3,50,81.3z"/>
                <path class="st1" d="M77.5,53.8h-55c-2.1,0-3.8-1.7-3.8-3.8s1.7-3.8,3.8-3.8h55c2.1,0,3.8,1.7,3.8,3.8S79.6,53.8,77.5,53.8z"/>
            </g>
            <g class="st2">
                <g class="st3">
                    <rect y="25" class="st4" width="100" height="50"/>
                    <rect x="25" class="st4" width="50" height="100"/>
                    <polyline class="st4" points="100,0 0,100 50,100 50,0 0,0 100,100 100,50 0,50"/>
                    <circle class="st4" cx="50" cy="50" r="50"/>
                    <rect x="14.6" y="14.6" class="st4" width="70.7" height="70.7"/>
                    <circle class="st4" cx="50" cy="50" r="35.4"/>
                    <circle class="st4" cx="50" cy="50" r="25"/>
                    <circle class="st4" cx="50" cy="50" r="12.5"/>
                </g>
            </g>
        </g>
	</svg>

</template>

<script>
export default {
  props:{
    color: String
  }
}
</script>

<style lang="scss" scoped>
svg{
    width: 32px;
    height: 32px;
}
.st0{fill:#44B69E;}
.st1{fill:#FFFFFF;}
.st2{display:none;}
.st3{display:inline;}
.st4{fill:none;stroke:#000000;stroke-width:0.1;stroke-miterlimit:10;}
</style>
