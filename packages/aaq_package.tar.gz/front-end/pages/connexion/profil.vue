<template>
  <section class="container">
    <b-container class="interventions">
      <b-row>
        <b-col cols="6" offset="3" >
            <div class="text-center mb-3">
              <h1>
                Édition des informations
              </h1>
            </div>
            <mon-compte :user="user" :check-legal="false" :submit-txt="'Enregistrer'" :cancel-txt="'Annuler'" @submit="editProfile" @cancel="cancelEdit"/>
        </b-col>
      </b-row>
    </b-container>
  </section>
</template>

<script>
import { mapState } from 'vuex'
import monCompte from '~/components/moncompte.vue'
export default {
  computed: {
    ...mapState({
      'user': state => JSON.parse(JSON.stringify(state.utilisateurCourant))
    }),
  },
  methods: {
    // Validation de l'inscription
    async editProfile(){
        const url = process.env.API_URL + `/connexion/edit-mon-compte/${this.user.id }`
        //console.log(url)
        //const url = process.env.API_URL + `/connexion/verify/${this.user.id }`
        //console.log(this.user.cpi_codeinsee)
        return this.$axios.$put(url, { profil: this.user })
        .then(async response => {
            await this.$store.dispatch('set_utilisateur', response.user);
            this.$toast.success('Profil enregistré avec succès.')
            // On renvoie vers la route par défaut (redirigé en fonction du profil par le middleware)
            this.$router.push('/')

        }).catch(err => {
            console.log(err)
        })
    },
    async cancelEdit(){
      // Annulation des modifications.
      this.$router.push('/')
    },

  },
  components: {monCompte}
};
</script>

<style>

</style>
